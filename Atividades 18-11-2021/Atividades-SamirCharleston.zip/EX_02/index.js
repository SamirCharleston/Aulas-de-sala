let base = window.prompt("Digite a base:");
let altura = window.prompt("Digite a altura:");

base = Number(base);
altura = Number(altura);

console.log("A area do retangulo é: " + (base * altura));