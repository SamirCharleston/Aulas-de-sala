let fator = 0;

fator = Number(window.prompt("Digite um numero"));

for (i = 0; i < 10; i++) {
    console.log((i + 1) * fator);
}