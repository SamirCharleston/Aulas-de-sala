let valor = 0;

valor = Number(window.prompt("Digite um valor:"));

if (valor > 100) {
    console.log("É MAIOR QUE 100!");
} else {
    console.log("NÃO É MAIRO QUE 100!");
}